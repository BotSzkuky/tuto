@include('includes.head')
@include('includes.nav')

<main role="main" class="container">
    @yield('content')
</main>

@include('includes.foot')
