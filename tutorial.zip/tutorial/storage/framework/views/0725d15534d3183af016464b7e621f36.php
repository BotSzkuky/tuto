<script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
<script src="/docs/4.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-1CmrxMRARb6aLqgBO7yyAxTOQE2AKb9GfXnEo760AUcUmFx3ibVJJAzGytlQcNXd" crossorigin="anonymous"></script>

<?php echo $__env->yieldContent('script', ''); ?>

</body>
</html>
<?php /**PATH C:\Users\berec\Downloads\Hengersoros cuccok egybe\phptutorial\tutorial\resources\views/includes/foot.blade.php ENDPATH**/ ?>