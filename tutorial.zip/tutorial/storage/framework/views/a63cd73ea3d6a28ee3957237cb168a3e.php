

<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <h1><?php echo e($randomName); ?></h1>
    <p class="lead">Ez az első demo route-unk!</p>
    <a class="btn btn-lg btn-primary" href="https://learn.pvga.hu" role="button">PVGA Learn »</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\berec\Downloads\Hengersoros cuccok egybe\phptutorial\tutorial\resources\views/teszt.blade.php ENDPATH**/ ?>