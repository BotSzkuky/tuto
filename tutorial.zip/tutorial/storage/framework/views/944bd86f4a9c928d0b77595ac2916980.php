<?php $__env->startSection('title', '| Nevek'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Azonosító</th>
                    <th>Családnév</th>
                    <th>Név</th>
                    <th>Létrehozás</th>
                    <th>Műveletek</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($name->id); ?></td>
                        <?php if(empty($name->family)): ?>
                            <td><strong>Nincs adat.</strong></td>
                        <?php else: ?>
                            <td><?php echo e($name->family->surname); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($name->name); ?></td>
                        <td><?php echo e($name->created_at); ?></td>
                        <td>
                            <a href="#" class="btn btn-sm btn-danger btn-delete-name" data-id="<?php echo e($name->id); ?>">Törlés</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h3 class="mt-3">Új név hozzáadása</h3>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form method="post" action="/names/manage/name/new">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="inputFamily">Családnév</label>
                <select id="inputFamily" name="inputFamily" class="form-control">
                    <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($family->id); ?>"><?php echo e($family->surname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="inputName">Keresztnév</label>
                <input type="text" class="form-control" id="inputName" name="inputName" value="<?php echo e(old('inputName')); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Hozzáadás</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(".btn-delete-name").on('click', function(){
            let thisBtn = $(this);
            let id = thisBtn.data('id');

            $.ajax({
                type: "POST",
                url: '/names/delete',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: id
                },
                success: function(){
                    thisBtn.closest('tr').fadeOut();
                },
                error: function(){
                    alert('Nem sikerült a törlés!');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\berec\Downloads\Hengersoros cuccok egybe\phptutorial\tutorial\resources\views/pages/names.blade.php ENDPATH**/ ?>